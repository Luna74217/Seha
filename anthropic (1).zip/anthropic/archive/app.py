from flask import Flask, request, render_template_string
import openai
import os
import json

app = Flask(__name__)
openai.api_key = os.environ.get("OPENAI_API_KEY", "")

def load_chat_history(filename="chat_history.json"):
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    return [{"role": "system", "content": "친절한 한국어 챗봇"}]

def save_chat_history(chat_history, filename="chat_history.json"):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(chat_history, f, ensure_ascii=False, indent=2)

def generate_response(chat_history):
    response = openai.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=chat_history,
        temperature=0.7,
        max_tokens=512,
        top_p=0.9
    )
    return response.choices[0].message.content.strip()

# 간단한 HTML 템플릿
TEMPLATE = """
<!doctype html>
<html>
  <head><meta charset="utf-8"><title>TS 챗봇</title></head>
  <body>
    <h1>TS 챗봇 (Flask)</h1>
    <div>
      {% for entry in chat_history %}
        <p><strong>{{ '🤖 소하' if entry.role=='assistant' else '👤 사용자' }}:</strong> {{ entry.content }}</p>
      {% endfor %}
    </div>
    <form method="post">
      <input name="user_input" style="width:80%;" autofocus autocomplete="off">
      <input type="submit" value="전송">
    </form>
  </body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    chat_history = load_chat_history()
    if request.method == "POST":
        user_input = request.form["user_input"].strip()
        if user_input:
            chat_history.append({"role": "user", "content": user_input})
            bot_reply = generate_response(chat_history)
            chat_history.append({"role": "assistant", "content": bot_reply})
            save_chat_history(chat_history)
    return render_template_string(TEMPLATE, chat_history=chat_history)

if __name__ == "__main__":
    app.run(debug=True)
