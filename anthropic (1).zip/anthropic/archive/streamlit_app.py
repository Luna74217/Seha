import streamlit as st
import openai
import os
import json

# (앞서 정의한 load_chat_history, save_chat_history 함수 포함)
def load_chat_history(filename="chat_history.json"):
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_chat_history(chat_history, filename="chat_history.json"):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(chat_history, f, ensure_ascii=False, indent=2)

def generate_response(chat_history):
    response = openai.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=chat_history,
        temperature=0.7,
        max_tokens=512,
        top_p=0.9,
        frequency_penalty=0.0,
        presence_penalty=0.0
    )
    return response.choices[0].message.content.strip()

def main():
    # API 키 설정
    openai.api_key = os.environ.get("OPENAI_API_KEY", "")
    if not openai.api_key:
        st.error("환경변수 OPENAI_API_KEY가 설정되지 않았습니다.")
        return

    st.title("TS 챗봇 (Streamlit 인터페이스)")
    chat_history = load_chat_history()
    if not chat_history:
        chat_history = [{"role": "system", "content": "당신은 친절한 한국어 챗봇입니다."}]

    # 대화창 렌더링
    for entry in chat_history:
        role = "🤖 소하" if entry["role"] == "assistant" else "👤 사용자"
        st.write(f"**{role}:** {entry['content']}")

    # 사용자 입력
    user_input = st.text_input("You:", "")
    if st.button("전송") and user_input:
        chat_history.append({"role": "user", "content": user_input})
        bot_reply = generate_response(chat_history)
        chat_history.append({"role": "assistant", "content": bot_reply})
        save_chat_history(chat_history)
        st.experimental_rerun()

if __name__ == "__main__":
    main()
