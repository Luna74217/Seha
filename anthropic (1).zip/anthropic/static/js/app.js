// app.js (static/js/app.js)

// Android 환경에서 키보드 올라올 때 레이아웃 밀림 방지
window.addEventListener('resize', function () {
  const chatContainer = document.querySelector('.chat-container');
  if (window.innerHeight < 600) {
    chatContainer.style.height = window.innerHeight * 0.8 + 'px';
  } else {
    chatContainer.style.height = 'auto';
  }
});

const messagesEl = document.getElementById('messages');
const inputEl = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');

// 메시지 추가 헬퍼 함수
function appendMessage(text, sender) {
  const msgDiv = document.createElement('div');
  msgDiv.classList.add('message', sender);
  msgDiv.textContent = text;
  messagesEl.appendChild(msgDiv);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

// 입력 전송 처리
function sendMessage() {
  const userText = inputEl.value.trim();
  if (!userText) return;
  appendMessage(userText, 'user');
  inputEl.value = '';

  // FastAPI 백엔드로 POST 요청
  fetch('/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'user', content: userText }] })
  })
    .then((res) => res.json())
    .then((data) => {
      appendMessage(data.response, 'soha');
      // data.state를 필요 시 로컬에 저장하거나 화면에 표시 가능
      console.log('Soha #STATE:', data.state);
    })
    .catch((err) => {
      console.error(err);
      appendMessage('죄송해요… 응답을 받지 못했어요.', 'soha');
    });
}

sendBtn.addEventListener('click', sendMessage);
inputEl.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') {
    sendMessage();
  }
});
